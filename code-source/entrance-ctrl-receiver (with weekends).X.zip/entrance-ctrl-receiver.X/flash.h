/* 
 * 
 * 
 *
 * 
 */

#ifndef FLASH_H
#define	FLASH_H

void Write_EEprom (signed char data, unsigned char adress);
signed char Read_EEprom (unsigned char adress);

#endif	/* FLASH_H */

