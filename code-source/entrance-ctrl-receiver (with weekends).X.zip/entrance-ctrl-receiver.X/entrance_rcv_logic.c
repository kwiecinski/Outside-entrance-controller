
#include <xc.h>
#include "circular_buffer.h"
#include "main.h"
#include "melody.h"
#include "manchester_decode.h"
#include "entrance_rcv_logic.h"

#define 


///////////////////////////////////////////////////////////////////////////////
///
/// 
/// 
/// 
///
///////////////////////////////////////////////////////////////////////////////

unsigned char Check_Event(DataStruct *DataRCV)
{
    if(DataRCV->frame[0]=='G' && DataRCV->frame[1]=='0')
    {
        Play_Ring();
        while(Frame_Decode(DataRCV)!=NO_DATA);
        return 1;
        
    }else if(DataRCV->frame[0]=='W' && DataRCV->frame[1]=='0')
    {
        Play_Ring();
        while(Frame_Decode(DataRCV)!=NO_DATA);
        return 1;
        
    }else if(DataRCV->frame[0]=='W' && DataRCV->frame[1]=='B')
    {

        Play_Ring();
        while(Frame_Decode(DataRCV)!=NO_DATA);
        return 1;
    }
    
    return 0;
}

