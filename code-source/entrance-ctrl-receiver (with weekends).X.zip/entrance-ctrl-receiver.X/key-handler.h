/* 
 * 
 * 
 *
 * 
 */

#ifndef KEY_HANDLER_H
#define	KEY_HANDLER_H

//enum button_press Button_Handler(KeyPointerStruct *keydef);
unsigned char Button_Handler(KeyPointerStruct *keydef);
void Button_Init (KeyPointerStruct *keydef);


#endif	/* KEY_HANDLER_H */

