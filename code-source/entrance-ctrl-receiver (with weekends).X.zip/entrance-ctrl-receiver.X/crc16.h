/* 
 * 
 * 
 *
 * 
 */

#ifndef CRC16_H
#define	CRC16_H

unsigned int CRC16(unsigned char *data_tab_ptr, unsigned char size);

#endif	/* CRC16_H */

