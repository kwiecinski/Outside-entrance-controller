/* 
 * 
 * 
 *
 * 
 */

#ifndef INITS_H
#define	INITS_H

void Global_Init(void);

#endif	/* INITS_H */

