/* 
 * FILE: main.c
 * DESCRIPTION: Main program body
 * AUTHOR: kwiecinski
 * DATE: 03.2020
 */

#include <xc.h>

#include "main.h"
#include "inits.h"
#include "entrance_rcv_logic.h"
#include "interrupts.h"
#include "hw_uart.h"
#include "circular_buffer.h"
#include "manchester_decode.h"
#include "crc16.h"
#include "melody.h"

void main(void) 
{  
    Global_Init();
    Interrupt_Init();
    CLRWDT();
    
    while(1)
    {   
       Check_RCV_Data();
    }
}