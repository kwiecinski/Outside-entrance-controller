/* 
 * 
 * 
 *
 * 
 */

#ifndef OTHERFUNCTIONS_H
#define	OTHERFUNCTIONS_H

#define WICKET          0
#define GATE            1
#define WICKET_BELL     2

unsigned char Check_Event(DataStruct *DataRCV);

#endif	/* OTHERFUNCTIONS_H */

