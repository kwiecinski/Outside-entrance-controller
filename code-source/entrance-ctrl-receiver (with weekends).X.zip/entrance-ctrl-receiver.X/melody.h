/* 
 * 
 * 
 *
 * 
 */

#ifndef MELODY_H
#define	MELODY_H


void Play_Ring(void);

#endif	/* MELODY_H */

