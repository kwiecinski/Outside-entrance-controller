/* 
 * 
 * 
 *
 * 
 */

#ifndef DISPLAY_7_SEGMENT_H
#define	DISPLAY_7_SEGMENT_H

void Display_7Seg(unsigned char *text, unsigned char decimal_point);
void Disable_All_Digits(void);

#endif	/* DISPLAY_7_SEGMENT_H */

