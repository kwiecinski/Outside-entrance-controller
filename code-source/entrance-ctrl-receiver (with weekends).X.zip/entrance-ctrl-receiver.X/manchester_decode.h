/* 
 * 
 * 
 *
 * 
 */

#ifndef MANCHESTER_H
#define	MANCHESTER_H

unsigned int Frame_Decode(DataStruct *DataRCV);
void Manchester_Decode(unsigned char *edge_dir, unsigned int *pulse_time);
void Check_RCV_Data(void);

#endif	/* MANCHESTER_H */

